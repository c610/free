import tkinter as tk
from libs.gui import SQLMapGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = SQLMapGUI(root)
    root.mainloop()



