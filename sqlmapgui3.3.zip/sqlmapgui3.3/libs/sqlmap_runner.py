import subprocess

class SQLMapRunner:
    def __init__(self, gui):
        self.gui = gui
        self.request_file = None  # Domyślnie brak wczytanego pliku requesta
        self.base_args = []  # Baza argumentów, które będą używane w każdym wywołaniu

    def start_sqlmap(self, url=None, request_file=None, custom_args=None):
        """Uruchamia sqlmap z odpowiednimi argumentami"""
        # Przygotowanie podstawowych argumentów
        args = ["sqlmap"]

        if url:
            args += ["-u", url]
        elif request_file:  # Jeśli przekazany jest plik, dodajemy odpowiedni argument
            args += ["-r", request_file]

        # Dodanie dodatkowych argumentów, jeśli zostały przekazane
        if custom_args:
            args.extend(custom_args)

        # Zachowanie argumentów dla debugowania
        self.base_args = args  # Zapisywanie podstawowych argumentów do ponownego wykorzystania

        # Debugowanie: pokazujemy pełne polecenie przed uruchomieniem
        self.gui.update_status(f"Uruchomienie sqlmap z argumentami: {' '.join(args)}", "info")

        # Uruchomienie sqlmap w subprocessie
        self.run_sqlmap(args)

    def run_sqlmap(self, args):
        """Uruchamia sqlmap z przekazanymi argumentami"""
        try:
            process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()

            # Przekazywanie wyników do GUI
            self.gui.output_text.insert("1.0", stdout.decode())
            if stderr:
                self.gui.output_text.insert("1.0", stderr.decode())

        except Exception as e:
            self.gui.update_status(f"Nie udało się uruchomić sqlmap: {e}", "status_error")

    def stop_sqlmap(self):
        """Zatrzymuje działający proces sqlmap (jeśli to możliwe)"""
        # Można dodać mechanizm zatrzymywania procesu, np. wysyłając SIGTERM
        self.gui.update_status("Zatrzymano skanowanie.", "status_info")
        # Dodaj kod do zakończenia procesu, np. os.kill()

    def add_custom_flag(self, flag):
        """Funkcja dodająca dodatkową flagę do aktualnych argumentów"""
        new_args = self.base_args + [flag]
        self.gui.update_status(f"Uruchamianie sqlmap z dodatkowymi flagami: {' '.join(new_args)}", "info")
        self.run_sqlmap(new_args)



