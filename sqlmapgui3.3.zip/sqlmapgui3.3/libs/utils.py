from datetime import datetime
import re

def get_timestamp():
    """Zwraca aktualny znacznik czasu"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def extract_sqlmap_info(log_data):
    """Ekstrahuje informacje z logu sqlmap, np. nazwę bazy danych"""
    match = re.search(r"available databases \[.*?\]:\n\[(.*?)\]", log_data)
    return match.group(1) if match else None



