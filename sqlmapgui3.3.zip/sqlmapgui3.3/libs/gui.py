import tkinter as tk
from tkinter import messagebox, filedialog, scrolledtext
from libs.sqlmap_runner import SQLMapRunner
from libs.icons import get_status_icon, COLORS
import subprocess
import threading  # Dodajemy import do threading

WINDOW_WIDTH = 740
WINDOW_HEIGHT = 740

class SQLMapGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("SQLMap GUI")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.resizable(False, False)

        self.sqlmap_runner = SQLMapRunner(self)

        self.last_sqlmap_command = None  # Zmienna do przechowywania ostatniego polecenia sqlmap

        self.create_widgets()

    def create_widgets(self):
        """Tworzenie widżetów GUI"""
        tk.Label(self.root, text="Target URL:", fg=COLORS["text"]).grid(row=0, column=0, padx=5, pady=5, sticky="w")

        self.url_entry = tk.Entry(self.root, width=50)
        self.url_entry.grid(row=0, column=1, padx=5, pady=5, columnspan=2, sticky="w")

        self.start_button = tk.Button(self.root, text="Start", width=10, command=self.start_sqlmap)
        self.start_button.grid(row=0, column=3, padx=5, pady=5)

        self.stop_button = tk.Button(self.root, text="Stop", width=10, command=self.sqlmap_runner.stop_sqlmap)
        self.stop_button.grid(row=1, column=3, padx=5, pady=5)

        # Niepotrzebne pole input usunięte

        # Nowe przyciski z funkcjami w dwóch liniach
        self.dump_all_button = tk.Button(self.root, text="Dump All", width=10, command=self.dump_all)
        self.dump_all_button.grid(row=3, column=0, padx=5, pady=5, sticky="w")

        self.dump_db_button = tk.Button(self.root, text="Dump DB", width=10, command=self.dump_db)
        self.dump_db_button.grid(row=3, column=1, padx=5, pady=5, sticky="w")

        self.enum_db_button = tk.Button(self.root, text="Enum DB", width=10, command=self.enum_db)
        self.enum_db_button.grid(row=3, column=2, padx=5, pady=5, sticky="w")

        self.list_dbs_button = tk.Button(self.root, text="List DBs", width=10, command=self.list_dbs)
        self.list_dbs_button.grid(row=4, column=0, padx=5, pady=5, sticky="w")

        self.get_pass_button = tk.Button(self.root, text="Get pass", width=10, command=self.get_pass)
        self.get_pass_button.grid(row=4, column=1, padx=5, pady=5, sticky="w")

        buttons = [
            ("Clear", self.clear_output),
            ("Save log", self.save_log),
            ("Open", self.open_request),
            ("Quit", self.root.quit)
        ]

        # Przyciski po prawej stronie
        for i, (text, command) in enumerate(buttons):
            btn = tk.Button(self.root, text=text, width=10, command=command)
            btn.grid(row=i+2, column=3, padx=5, pady=5, sticky="n")  # Przesunięcie o 1 rząd w dół

        self.create_checkboxes()

        self.status_label = tk.Label(self.root, text="Status: Oczekiwanie...", fg=COLORS["status_wait"])
        self.status_label.grid(row=6, column=0, columnspan=3, pady=10, sticky="w")

        self.output_text = scrolledtext.ScrolledText(self.root, width=85, height=20, bg=COLORS["background"], wrap=tk.WORD)
        self.output_text.grid(row=7, column=0, columnspan=4, padx=5, pady=5)

    def update_status(self, text, status_type="info"):
        """Aktualizuje status z ikoną"""
        icon = get_status_icon(status_type)
        # Używamy domyślnego koloru z 'info', jeśli 'status_type' nie istnieje w COLORS
        color = COLORS.get(status_type, COLORS.get("info", "black"))
        self.status_label.config(text=f"{icon} {text}", fg=color)


    def clear_output(self):
        """Czyści okno wyników"""
        self.output_text.delete(1.0, tk.END)

    def save_log(self):
        """Zapisuje logi do pliku"""
        file_path = filedialog.asksaveasfilename(defaultextension=".txt")
        if file_path:
            with open(file_path, "w") as file:
                file.write(self.output_text.get(1.0, tk.END))
            messagebox.showinfo("Zapisano", f"Log zapisany: {file_path}")

    def create_checkboxes(self):
        """Tworzenie checkboxów DB, Level, Risk ustawionych obok siebie, wyrównanych do lewej"""
        container = tk.Frame(self.root)
        container.grid(row=1, column=0, columnspan=3, padx=5, pady=5, sticky="w")

        self.db_vars = {"mysql": tk.IntVar(), "postgres": tk.IntVar(), "all": tk.IntVar()}
        self.level_vars = {"1": tk.IntVar(), "2": tk.IntVar(), "3": tk.IntVar()}
        self.risk_vars = {"1": tk.IntVar(), "2": tk.IntVar(), "3": tk.IntVar()}

        # Ramka dla DB
        db_frame = tk.Frame(container)
        db_frame.pack(side="left", padx=2)
        tk.Label(db_frame, text="DB:").pack(anchor="w")
        for db, var in self.db_vars.items():
            tk.Checkbutton(db_frame, text=db, variable=var).pack(anchor="w")

        # Ramka dla Level
        level_frame = tk.Frame(container)
        level_frame.pack(side="left", padx=2)
        tk.Label(level_frame, text="Level:").pack(anchor="w")
        for lvl, var in self.level_vars.items():
            tk.Checkbutton(level_frame, text=f"level {lvl}", variable=var).pack(anchor="w")

        # Ramka dla Risk
        risk_frame = tk.Frame(container)
        risk_frame.pack(side="left", padx=2)
        tk.Label(risk_frame, text="Risk:").pack(anchor="w")
        for rsk, var in self.risk_vars.items():
            tk.Checkbutton(risk_frame, text=rsk, variable=var).pack(anchor="w")

    def open_request(self):
        """Wczytuje plik requesta"""
        file_path = filedialog.askopenfilename(filetypes=[("Pliki tekstowe", "*.txt")])
        if file_path:
            self.sqlmap_runner.request_file = file_path  
            self.url_entry.delete(0, tk.END)  
            self.update_status(f"Wczytano plik: {file_path}", "info")

    def start_sqlmap(self):
        """Uruchamia sqlmap, uwzględniając zarówno URL jak i plik requesta"""
        url = self.url_entry.get().strip()  # URL wprowadzone przez użytkownika

        def run_sqlmap_in_thread():
            # Jeśli plik requesta został wczytany, to nie używamy URL, tylko plik
            if self.sqlmap_runner.request_file:
                if url:  # Jeśli podano URL, resetujemy go
                    self.url_entry.delete(0, tk.END)  # Kasujemy pole URL
                self.last_sqlmap_command = f"sqlmap -r {self.sqlmap_runner.request_file} --batch"  # Pamiętamy polecenie
                self.sqlmap_runner.start_sqlmap(request_file=self.sqlmap_runner.request_file)
                self.update_status("Skanowanie z plikiem requesta", "info")
            elif url:  # Jeśli URL jest dostępny, uruchamiamy skanowanie z URL
                self.last_sqlmap_command = f"sqlmap -u {url} --batch"  # Pamiętamy polecenie
                self.sqlmap_runner.start_sqlmap(url=url)
                self.update_status(f"Skanowanie z URL: {url}", "info")
            else:
                # Jeśli ani URL ani plik requesta nie są podane, wyświetlamy komunikat o błędzie
                self.update_status("Brak URL do skanowania.", "status_error")
                messagebox.showerror("Błąd", "Nie podano adresu URL lub pliku requesta.")

        threading.Thread(target=run_sqlmap_in_thread, daemon=True).start()  # Uruchamiamy wątek

    # Funkcje dla przycisków Dump All, Dump DB, Enum DB, List DBs, Get pass
    def dump_all(self):
        self.run_sqlmap_with_flags("--dump-all")

    def dump_db(self):
        self.run_sqlmap_with_flags("--dump --batch")

    def enum_db(self):
        self.run_sqlmap_with_flags("--current-user", "--current-db", "-b")

    def list_dbs(self):
        self.run_sqlmap_with_flags("--dbs")

    def get_pass(self):
        self.run_sqlmap_with_flags("--passwords --batch")

    def run_sqlmap_with_flags(self, *flags):
        """Uruchamia sqlmap z dodanymi flagami do ostatniego polecenia"""
        if self.last_sqlmap_command:
            command = f"{self.last_sqlmap_command} {' '.join(flags)}"
            self.sqlmap_runner.start_sqlmap(custom_args=command.split())
            self.update_status(f"Uruchomiono: {command}", "info")
        else:
            messagebox.showerror("Błąd", "Brak ostatniego polecenia sqlmap. Uruchom sqlmap przed dodaniem flagi.")

    def insert_result(self, result):
        """Dodaje wynik do okna tekstowego (najświeższy wynik na górze) i przewija automatycznie do początku."""
        self.output_text.insert("1.0", result + '\n')
        self.output_text.yview_moveto(0)



