COLORS = {
    "text": "black",
    "background": "#f0f0f0",
    "status_wait": "blue",
    "status_start": "green",
    "status_done": "darkgreen",
    "status_stop": "red",
    "status_vuln": "purple",
    "status_error": "darkred",
    "info": "black"  # ✅ Dodano brakujący wpis
}

def get_status_icon(status_type):
    icons = {
        "status_wait": "🕒",
        "status_start": "🚀",
        "status_done": "✅",
        "status_stop": "⛔",
        "status_vuln": "⚠️",
        "status_error": "❌"
    }
    return icons.get(status_type, "ℹ️")



